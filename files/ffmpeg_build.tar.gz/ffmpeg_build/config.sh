#! /bin/bash

# enableShared=[treu/false]
enableShared=false # 是否开启动态库(全局配置)
